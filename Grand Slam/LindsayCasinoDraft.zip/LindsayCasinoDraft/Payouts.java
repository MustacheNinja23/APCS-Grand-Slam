
public class Payouts {
	
	public Payouts() {
		
	}
	
}
